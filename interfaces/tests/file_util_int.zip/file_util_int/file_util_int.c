// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#include <stdlib.h>
#include <inttypes.h>
#include <string.h> // IWYU pragma: keep
#include <fcntl.h>
#include <stdbool.h>

#include "macro_utils/macro_utils.h" // IWYU pragma: keep

#include "testrunnerswitcher.h"
#include "umock_c/umock_c.h"

#include "c_pal/gballoc_hl.h"
#include "c_pal/gballoc_hl_redirect.h"

#include "umock_c/umock_c_prod.h"

#include "c_pal/windows_defines.h"

#include "c_pal/file_util.h"
#include "c_pal/thandle.h"
#include "c_pal/threadpool.h"

/* static const char* G_FILE_NAME = "test_file"; */


BEGIN_TEST_SUITE(TEST_SUITE_NAME_FROM_CMAKE)

TEST_SUITE_INITIALIZE(suite_init)
{

}

TEST_SUITE_CLEANUP(suite_cleanup)
{

}

TEST_FUNCTION_INITIALIZE(TestMethodInitialize)
{
    umock_c_reset_all_calls();
}

TEST_FUNCTION_CLEANUP(TestMethodCleanup)
{

}

/*Tests_SRS_FILE_UTIL_LINUX_09_001: [ If the full_file_name input is either empty or NULL, file_util_open_file shall return an INVALID_HANDLE_VALUE. ]*/
TEST_FUNCTION(create_5K_file)
{
    ///arrange
    HANDLE result;
    int tp_success;

    ///act
    const char* full_file_name = "C:\devsecond";
    uint32_t desired_access = GENERIC_READ;
    uint32_t share_mode = FILE_SHARE_READ;
    uint32_t creation_disposition = 1;
    uint32_t flags_and_attributes = 128;
    result = file_util_open_file(full_file_name, desired_access, share_mode, NULL,creation_disposition, flags_and_attributes ,NULL);
    ASSERT_ARE_NOT_EQUAL(uint64_t, result, INVALID_HANDLE_VALUE);

    THANDLE(THREADPOOL) file_threadpool = threadpool_create(execution_engine);
    ASSERT_IS_NOT_NULL(threadpool);

    tp_success = threadpool_close(file_threadpool);

    ///assert
    ASSERT_ARE_EQUAL(int, tp_success, 0);

    ///Cleanup
}

END_TEST_SUITE(TEST_SUITE_NAME_FROM_CMAKE)
